// Initialisation des données avec une liste de contacts fictive
Page({
    data: {
      contacts: [
        { id: 1, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 2, name: "Arouna Kone", phone: "+228 07481777" },
        { id: 3, name: "Anne Esther", phone: "+228 07481777" },
        { id: 4, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 5, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 6, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 7, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 8, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 9, name: "Angban Gpt", phone: "+228 07481777" },
        { id: 10, name: "Angban Gpt", phone: "+228 07481777" }
      ].map(item => ({ ...item, selected: false })), // Ajout de la propriété "selected" pour chaque contact
      multiSelect: false // Mode de sélection multiple désactivé par défaut
    },
  
  
    // Basculer le mode de sélection multiple
    toggleMultiSelect() {
      this.setData({
        multiSelect: !this.data.multiSelect // Inverse l'état du mode multi-sélection
      });
      // Réinitialise la sélection si le mode est désactivé
      if (!this.data.multiSelect) {
        this.setData({
          contacts: this.data.contacts.map(item => ({ ...item, selected: false }))
        });
      }
    },
  
  
    // Gérer la sélection d'un contact
    selectContact(e) {
      if (this.data.multiSelect) { // Vérifie si le mode multi-sélection est activé
        const index = e.currentTarget.dataset.index; // Récupère l'index du contact cliqué
        const contacts = this.data.contacts;
        contacts[index].selected = !contacts[index].selected; // Inverse l'état de sélection
        this.setData({
          contacts: contacts // Met à jour la liste des contacts
        });
      }
    },
  
  
    // Retourner en arrière (action de l'icône)
    goBack() {
      wx.navigateBack(); // Retourne à la page précédente
    },
  
  
    // Naviguer vers une autre page en cliquant sur "Ignorer"
    navigateAway() {
      wx.navigateTo({
        url: '/pages/index/homePage' // Remplace par le chemin de la page cible
      });
    },
  
  
    // Optionnel : Récupérer les contacts réels (décommenter et ajuster si l'API est disponible)
    /*
    onLoad() {
      wx.getPhoneContacts({
        success: (res) => {
          this.setData({
            contacts: res.contacts.map(contact => ({
              id: contact.id,
              name: contact.displayName || contact.name,
              phone: contact.phoneNumber,
              selected: false
            }))
          });
        },
        fail: () => {
          console.log("Échec de la récupération des contacts");
        }
      });
    }
    */
  });
  
  
  