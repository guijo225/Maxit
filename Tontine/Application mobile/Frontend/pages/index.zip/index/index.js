Page({
    data: {
        showModal: false,
        formData: {
            nom: '',
            description: '',
            modalite: '',
            montant: '',
            frequence: '',
            participants: ''
        },

        frequenceOptions: ['Mensuelle', 'Hebdomadaire', 'Quinzaine', 'Annuelle']
    },

    openModal() {
        this.setData({ showModal: true });
    },

    closeModal() {
        this.setData({ showModal: false });
    },

    onInputChange(e) {
        const field = e.currentTarget.dataset.field;
        const value = e.detail.value;
        this.setData({
            [`formData.${field}`]: value
        });
    },

    openFrequenceOptions() {
        const that = this;
        wx.showActionSheet({
            itemList: this.data.frequenceOptions,
            success(res) {
                const selected = that.data.frequenceOptions[res.tapIndex];
                that.setData({
                    'formData.frequence': selected
                });
            },
            fail(err) {
                console.log('Annulé ou erreur', err);
            }
        });
    },

    // Bouton Suivant : navigation vers la prochaine page
    confirmModal() {
        const that = this;

        // Affiche un loader système natif pendant la transition
        wx.showLoading({
            mask: true // Empêche de cliquer derrière pendant le chargement
        });

        // Petit délai pour laisser le loader visible avant de naviguer
        setTimeout(() => {
            // Navigation propre sans empilement de pages superflues
            wx.redirectTo({
                url: '/pages/index/PageContact',
                success() {
                    // Optionnel : on peut cacher le loader ici mais la page sera détruite donc pas nécessaire
                    wx.hideLoading();
                },
                fail(err) {
                    console.error('Erreur de navigation :', err);
                    wx.hideLoading();
                    wx.showToast({
                        title: 'Erreur de navigation',
                        icon: 'none'
                    });
                }
            });
        }, 600); // délai ajustable (300-500 ms pour un effet fluide)
    }

});
